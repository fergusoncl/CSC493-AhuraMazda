﻿using UnityEngine;
using System.Collections;

public class splashGUI : MonoBehaviour 
{
	public GUISkin customSkin = null;
	
	public void OnGUI()
	{
		if(customSkin != null)
		{
			GUI.skin = customSkin;
		}
		
		int buttonWidth = 100;
		int buttonHeight = 100;
		
		if(GUI.Button (new Rect(580, 384, buttonWidth, buttonHeight), "Play"))
		{
			Application.LoadLevel("Practice");
		}
	}
}

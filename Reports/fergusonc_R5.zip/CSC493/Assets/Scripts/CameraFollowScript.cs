/*
Name: Cody Ferguson
Project: Titan Quest
*/

using UnityEngine;
using System.Collections;

public class CameraFollowScript : MonoBehaviour {

	public Transform target;
	public Transform MyCamera;
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () 
	{
		// This simply sets the camera position. Nothing fancy.
		MyCamera.position = new Vector3(target.position.x, target.position.y + 10, target.position.z);
	}
}

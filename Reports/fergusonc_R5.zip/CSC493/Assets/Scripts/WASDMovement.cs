/*
Name: Cody Ferguson
Project: Titan Quest
*/


using UnityEngine;
using System.Collections;
#pragma strict

public class WASDMovement : MonoBehaviour 
{	
	// Variables for holding the player object, and the target of the player. Additionally, the variable holding the player's movement speed.
	float MoveSpeed = 1;
	public Rigidbody player;
	public Rigidbody target;
	
	// Update is called once per frame
	void Update ()
	{
		// If the input key is W, move the character.
		if(Input.GetKeyDown(KeyCode.W))
		{
			player.position = new Vector3(player.position.x, player.position.y, player.position.z - MoveSpeed);
		}
		// If the input key is A, move the character.
		if(Input.GetKeyDown(KeyCode.A))
		{
			player.position = new Vector3(player.position.x + MoveSpeed, player.position.y, player.position.z);
		}
		// If the input key is D, move the character.
		if(Input.GetKeyDown(KeyCode.D))
		{
			player.position = new Vector3(player.position.x - MoveSpeed, player.position.y, player.position.z);
		}
		// If the input key is S, move the character.
		if(Input.GetKeyDown(KeyCode.S))
		{
			player.position = new Vector3(player.position.x, player.position.y, player.position.z + MoveSpeed);
		}
		
		// get the direction of the RayCast.
		var dir = transform.TransformDirection(player.position.x, player.position.y, player.position.z);
		
		// make a var for holding the raycast information
		RaycastHit hit;
		
		// Player attack
		if(Input.GetKeyDown(KeyCode.F))
		{
			// the player presses F, casts a ray and the information is returned in "hit" object.
			if(Physics.Raycast(player.position, dir, out hit, 4.0f))
			{
				// if what was hit is an enemy - destroy it.
				if(hit.collider.tag == "enemy")
				{
					Destroy(hit.transform.gameObject);
				}
			}
		}
	}
}

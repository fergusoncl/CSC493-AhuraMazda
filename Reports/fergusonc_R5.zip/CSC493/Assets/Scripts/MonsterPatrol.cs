/*
Name: Cody Ferguson
Project: Titan Quest
*/

using UnityEngine;
using System.Collections;

public class MonsterPatrol : MonoBehaviour {
	
	public float randAxis = 0.0f;
	public Transform target;
	public Transform player;
	public double timer = 0.0f;
	public bool move = false;
	float distanceFromTarget;
//	bool playerNear;
	float zDifference;
	float xDifference;
	
	// Update is called once per frame
	void Update () 
	{
		// calculate the distance from the player
		distanceFromTarget = Vector3.Distance(target.position, player.position);
		
		// compare to the npc's aggro range
		//playerNear = (distanceFromTarget < 10);
		
		/*
		// currently breaks unity
		if(playerNear)
		{
			StartCoroutine(Chase());
		}
		*/
		
		if(!move)
		{
			timer += Time.deltaTime;
		}
		
		if(timer >= 2)
		{
			StartCoroutine(Patrol());
		}
	}
	// patrol
	IEnumerator Patrol()
	{
		// stop counting
		move = true;
		
		// reset timer
		timer = 0;
		
		// generate an offset
		randAxis = Random.Range(0.6f, 1.0f);
		
		// pick one of four directions - move in that direction for the offset.
		switch(Random.Range(1, 4))
		{
		case 1:
			target.position = new Vector3(target.position.x, target.position.y, target.position.z - randAxis);
			break;
		case 2:
			target.position = new Vector3(target.position.x + randAxis, target.position.y, target.position.z);
			break;
		case 3:
			target.position = new Vector3(target.position.x, target.position.y, target.position.z + randAxis);
			break;
		case 4:
			target.position = new Vector3(target.position.x - randAxis, target.position.y, target.position.z);
			break;
		default:
			target.position = new Vector3(target.position.x, target.position.y, target.position.z - randAxis);
			break;
		}
		
		// Wait a second(or two) so...
		yield return new WaitForSeconds(2.0f);
		
		// Okay, lets move again! (by move, I mean count again! Hehe.
		move = false;
	}
	

	
	IEnumerator Chase()
	{
		// stop counting
		move = true;
		
		// reset timer @ the end
		timer = 0;
		
		// While in range, Chase!
		while(distanceFromTarget <= 10.0)
		{
			// If the players's Z value is larger, make targets larger.
			if(player.position.z > target.position.z)
			{
				target.position = new Vector3(target.position.x, target.position.y, target.position.z + 1.0f);
			}
			// If the player's Z value is smaller, make targets smaller.
			else if(player.position.z < target.position.z)
			{
				target.position = new Vector3(target.position.x, target.position.y, target.position.z - 1.0f);
			}
			// If the players's X value is larger, make targets larger.
			else if(player.position.x > target.position.x)
			{
				target.position = new Vector3(target.position.x + 1.0f, target.position.y, target.position.z);
			}
			// If the player's X value is smaller, make targets smaller.
			else if(player.position.x < target.position.x)
			{
				target.position = new Vector3(target.position.x - 1.0f, target.position.y, target.position.z);
			}
		
			// Move, then check the range to the target.
			distanceFromTarget = Vector3.Distance(target.position, player.position);
		}
		
		
		// Wait a second(or two) so...
		yield return new WaitForSeconds(2.0f);
		
		move = false;
		
	}
}

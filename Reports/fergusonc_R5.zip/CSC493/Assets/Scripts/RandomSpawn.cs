/*
Name: Cody Ferguson
Project: Titan Quest
*/

using UnityEngine;
using System.Collections;

public class RandomSpawn : MonoBehaviour {
	
	bool spawn = false;
	double timer = 0.0f;
	public Object prefab;
	public Transform[] spawnpoints;
	
	// Update is called once per frame
	void Update () 
	{
		if(!spawn)
		{
			timer += Time.deltaTime;
		}
	
		if(timer >= 5)
		{
			StartCoroutine(Spawn());	
		}
	}
	
	IEnumerator Spawn()
	{
		// turn off the spawning check...
		spawn = true;
		
		// reset the timer, for future spawns...
		timer = 0;
		
		// generate a displacement value, for sending the spawned prefab a distance from the spawn point.
		float displacement = Mathf.Abs (Random.Range (3,7));
		
		// pick a random location.
		Transform location = spawnpoints[Random.Range (0,1)];
		
		// pick a random case, set the new location of the transform!
		switch(Random.Range (1,4))
		{
		case 1:
			location.position = new Vector3(location.position.x, location.position.y, location.position.z - displacement);
			break;
		case 2:
			location.position = new Vector3(location.position.x - displacement, location.position.y, location.position.z);
			break;
		case 3:
			location.position = new Vector3(location.position.x, location.position.y, location.position.z + displacement);
			break;
		case 4:
			location.position = new Vector3(location.position.x + displacement, location.position.y, location.position.z);
			break;
		default:
			location.position = new Vector3(location.position.x, location.position.y, location.position.z);
			break;
		}
		
		// instantiate the object at the newly defined location
		Instantiate(prefab, location.position, location.rotation);
		
		// wait before returning to the spawn cycle
		yield return new WaitForSeconds(2.0f);
		
		// We are no longer spawning.
		spawn = false;
	}
	
}

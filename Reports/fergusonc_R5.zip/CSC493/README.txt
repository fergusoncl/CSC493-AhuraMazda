Application Name: Titan Quest

Project Author: Cody Ferguson
		fergusonc@berea.edu
		codyferguson@outlook.com
		(502)331-8224

System and Hardware Requirements:

	Windows Operating System
	1 GB of RAM
	Any processor released after 2005
	512 MB of Graphic Memory
	Unity3D installed
	
Installation Instructions:

	Download and Install Unity3D if you do not already have it:
		http://unity3d.com/unity/download

	Open TitanQuest.exe and Play!

How to Play:

	Move the player character with the W,A,S, and D keys.
	Attack and Interact with the F key.
	
	Coming Soon:
	
	Press 1,2,3,4 to activate different abilities.
	